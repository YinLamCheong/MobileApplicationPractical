package com.example.recycleviewexample

data class Student(val ImageResource:Int, val name:String, val programme:String)
//getter setter will declare auto, no need write out